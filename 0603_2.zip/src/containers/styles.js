const styles = {
  form: {
    border: '1px solid gray',
    padding: 10
  },
  name: {
    float: 'left',
    width: 100,
    color: 'blue',
    textAlign: 'right'
  },
  msg: {
    float: 'left'
  }
}

export default styles


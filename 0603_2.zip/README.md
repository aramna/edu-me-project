use 'yarn' (yarn 사용 권장!)
=
'yarn' 설치 
- npm install -g yarn
 
프로젝트 사용방법

- yarn install
- 배포모드 : yarn build -> yarn start
- 개발모드 : yarn development -> localhost:4000